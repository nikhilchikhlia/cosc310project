package ChatBotAndTest;

public class GreetTest {
	private static GreetTest instance = null;
	public static void main(String[] args) {
//		ChatBot chat = new ChatBot();
//		chat.Greet("nikky");
		Bot helperBot = new Bot();
		ChatBot bot1 = new ChatBot();
		
		bot1.newUser("Nikky");
		helperBot.BotA();
		helperBot.botSpeak("Hello, " + bot1.name + "! Welcome.");
		helperBot.botSpeak("Please state the current theme of your issue so that I may assist you the best.");
	}
//	public static GreetTest getInstance() {
//		if(instance == null)
//			instance = new GreetTest();
//		return instance;
//	}
}
