package ChatBotAndTest;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
//import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
	
//import javax.swing.*;

public class Bot extends ChatBot {
	
	private static Bot instance = null;
	private JTextArea chatArea = new JTextArea();
	private JTextField chatBox = new JTextField();
//	private JLabel label = new JLabel();
	private JPanel contentPane;
	
	public void BotA() {
		JFrame frame = new JFrame();
		ImageIcon icon = new ImageIcon("src/ChatBotAndTest/Robot.png");
		frame.setIconImage(icon.getImage());
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setSize(600, 600);
	       contentPane = new JPanel();
	        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	        contentPane.setLayout(new BorderLayout(0, 0));
//	        setContentPane(contentPane);
	        JTextArea textArea = new JTextArea("Test");
	        textArea.setSize(400, 400);
	        JScrollPane scroll = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	        frame.getContentPane().add(scroll);
		frame.setTitle("Mental Health Chatbot");

		frame.add(chatArea);	
		frame.add(chatBox);



		//Chat Area
		chatArea.setSize(580, 400);
		chatArea.setLocation(2, 2);
		
		//Text Box
		chatBox.setSize(580,30);
		chatBox.setLocation(2,500);
		
		//Bot Introduction
//		botSpeak("Hello Welcome!");
		
		chatBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String gText = chatBox.getText();
				chatArea.append("YOU: " + gText + "\n");
				chatBox.setText("");
				
//				if(gText.contains("Hi")) {
//					botSpeak("Yo");
//				}else if(gText.contains("die")){
//					botSpeak("Let me die too");
//				}else {
//					botSpeak("Can you say that again?");
//				}
				
				boolean done = false;
				while (!done) {
//					gText = chatBox.getText();
//					chatArea.append("YOU: " + gText + "\n");
//					chatBox.setText("");
//					botSpeak("You didn't enter a proper theme, try again!");
					switch(gText) {
						case "Anxiety":
							anxiety.anxietyInvoked(ChatBot.name);
							done = true;
							break;
						case "Depression":
							depression.depressionInvoked(ChatBot.name);
							done = true;
							break;
						case "Emergency":
							emergency.emergencyInvoked(ChatBot.name);
							done = true;
							break;
						case "Happy":
							happy.happyInvoked(ChatBot.name);
							done = true;
							break;
						case "Others":
							other.othersInvoked(ChatBot.name);
							done = true;
							break;
						case "Stressed":
							stress.stressedInvoked(ChatBot.name);
							done = true;
							break;
						default:
							botSpeak("You didn't enter a proper theme, try again!");
							done = true;
							break;
					}
				
				}
			
		}});
		
	}
	
	public void botSpeak(String string) {
		chatArea.append("HELPER: " + string + "\n");
	}
	
	public static Bot getInstance() {
		if(instance == null)
			instance = new Bot();
		return instance;
	}

	public static void main(String[] args) {


	}

}
