package Moods;

public class Happy {
	public void happyInvoked(String userName) {
		System.out.println("I'm so glad to hear you are feeling happy! Continue to spread your positivity :)");
		System.out.println("Thank you for using your our service, " + userName + "!");
	}
}
