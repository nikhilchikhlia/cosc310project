package Moods;

import java.io.IOException;
import java.util.Scanner;

import InterfacesMoods.MentIllnessTherapist;
import InterfacesMoods.OtherTherapist;
import Therapists.TherapistConnection;

public class Others implements OtherTherapist, MentIllnessTherapist{
	public void othersInvoked(String userName) {
		Scanner standardInput = new Scanner(System.in);
		System.out.println("I'm sorry I cannot help you with your specific mood.");
		System.out.println("If you are not suffering from mental health, perhaps you would like to talk to someone about mental illnesses? \nPlease reply with a yes or no. (Y/N)");
		boolean done = false;
		while(!done) {
			String yesOrNo = (String) standardInput.next();
			if(yesOrNo.equals("Y")) {
				System.out.println("Please wait while we connect you with a therapist concerning mental illnesses.");
				TherapistConnection mentalIllnessTherapist = new TherapistConnection();
				mentalIllnessTherapist.MentIllnessTherapistInvoked(userName);
				done = true;
			}
			else if(yesOrNo.equals("N")) {
				System.out.println("It seems you do not have a mentall illness then. As such, would you like to be connected with a therapist to pinpoint"
						+ " your mood?");
				TherapistConnection otherTherapist = new TherapistConnection();
				done = false;
				while(!done) {
					yesOrNo = (String) standardInput.next();
					if(yesOrNo.equals("Y")) {
						System.out.println("Please wait while we connect you with a therapist.");
						otherTherapist.OtherTherapistInvoked(userName);
						done = true;
						
					}
					else if(yesOrNo.equals("N")) {
						System.out.println("Thank you for using our service, " + userName + "!");
						done = true;
					}
					else {
						System.out.println("You entered a wrong character! Please try again. (Y/N)");
						done = false;
					}
				}
			}
			else {
				System.out.println("You entered a wrong character! Please try again. (Y/N)");
			}
		}
		
		standardInput.close();
	}
}
